﻿
public class Todoitem
{
    private string a { get; set; }
    private string b { get; set; }
    }


